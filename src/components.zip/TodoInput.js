import React from 'react';

const TodoInput = () => {
  return <div>TodoInput</div>;
};

export default TodoInput;
