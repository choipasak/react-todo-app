import React from 'react';

const TodoItem = () => {
  return <li className='todo-list-item'></li>;
};

export default TodoItem;
